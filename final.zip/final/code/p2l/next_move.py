PRINT(get_location((10, 10), 0))
PRINT(get_location((10, 10), 1))
PRINT(get_location((10, 10), 2))
PRINT(get_location((10, 10), 3))

# Expected output
# (10, 9)
# (11, 10)
# (10, 11)
# (9, 10)
