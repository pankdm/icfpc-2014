# should compiled with
# --use_real_main=True

def main(ai_state, world):
    PRINT(ai_state)
    PRINT(world)
    return (0, 2)

