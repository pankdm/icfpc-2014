def foo(iterations):
    while iterations > 0:
        PRINT(iterations)
        iterations = iterations - 1

foo(5)
