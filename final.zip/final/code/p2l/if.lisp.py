

def f(x):
    if (x > 50):
        PRINT(x)
    else:
        PRINT(0)


f(70)
f(20)
