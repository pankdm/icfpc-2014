


def foo():
    x = 1300
    y = 11
    PRINT(x / y)

foo()


# prints:
# 118
