

def foo(z):
    x = 10
    PRINT(x)
    y = 20
    PRINT(y)
    PRINT(x+y+z)

foo(3)

# prints
# 10
# 20
# 23
