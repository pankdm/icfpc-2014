def is_wall(value):
    return value == WALL

PRINT(is_wall(0))
PRINT(is_wall(1))
# Expected output:
# 1
# 0
