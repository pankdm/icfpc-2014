PRINT(LENGTH([1, 2, 3, 4]))
PRINT(LENGTH([1]))
PRINT(LENGTH([]))

# Expected:
# 4
# 1
# 0
