

def f(a, b):
    x = a % b
    PRINT(x)

f(148, 100)
f(10, 3)
f(12, 4)

# prints
# 48
# 1
# 0
