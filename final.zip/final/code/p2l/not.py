def foo(x):
    return not x

PRINT(foo(1))
PRINT(foo(0))
