


def f():
	PRINT(10)


def main():
	f()
