

def foo(y):
    PRINT(y)

def bar(x):
    foo(x + 2)

bar(2)
