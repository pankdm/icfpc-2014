

def foo(x):
    PRINT(x)

foo(1)
foo(2)
foo(3)


