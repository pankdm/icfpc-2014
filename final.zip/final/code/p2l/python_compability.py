import math
from random import *

def foobar():
    return 2

PRINT(foobar())
