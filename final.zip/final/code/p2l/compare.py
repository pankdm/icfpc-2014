def compare(a, b):
    if a == b:
        PRINT(0)
    else:
        if a > b:
            PRINT(1)
        else:
            PRINT(-1)

compare(0, 0)
compare(1, 0)
compare(0, 1)
# Prints:
# 0
# 1
# -1
