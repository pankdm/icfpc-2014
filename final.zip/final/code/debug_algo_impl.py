from python_stl import *
import random
import math


def real_main(ai_state, world):
    PRINT(ai_state)
    PRINT(world)
