Module(body=[
    Expr(value=Call(func=Name(id='PRINT', ctx=Load()), args=[
        BinOp(left=Num(n=10), op=Add(), right=Num(n=15)),
      ], keywords=[], starargs=None, kwargs=None)),
  ])
