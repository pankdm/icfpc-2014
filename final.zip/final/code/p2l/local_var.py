

def foo(x):
    PRINT(x)
    x = 10
    PRINT(x)

foo(5)

# prints
# 5
# 10
