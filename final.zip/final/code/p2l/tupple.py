def foo(xy):
    PRINT(xy)

foo((3,5,7))

# prints
# (3, (5, 7))
