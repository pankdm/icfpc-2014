

def f(x):
    if x > 0:
        return 100
    return -100


