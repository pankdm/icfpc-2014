

def foo():
    x = (10, 20)
    y = (30, 40)
    PRINT(FIRST(x) + SECOND(y))

foo()

# prints 50
