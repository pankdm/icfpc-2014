

def f(x):
    if (x):
        PRINT(x)
    else:
        PRINT(10)

f(0)
f(100)
